//1.we create a variable fro XMLHTTPRequest
var request = new XMLHttpRequest();
//2.create a connection
request.open('GET', 'https://restcountries.eu/rest/v2/all', true)
//3.send the request
request.send();
//4.load the data
let countrydata;
let sum = 0;
let data
var style = "color: #5EB4B3; font-size: 20px ";
request.onload = function () {
    countrydata = JSON.parse(this.response);
    //Solving problems using array functions on rest countries data. 
    //1.Get all the countries from Asia continent / “region” using Filter method
    console.log("%c1.Get all the countries from Asia continent / “region” using Filter method",style)
    let array = []
    countrydata.filter(function (countrydata) {
        if (countrydata.region == "Asia") {
            array.push(countrydata.name)
        }
    })
    console.log(array)
    array = []
    //2.Get all the countries with population of less than 2 lacs using Filter method
    console.log("%c2.Get all the countries with population of less than 2 lacs using Filter metho",style)
    let pop_1 = countrydata.filter(function (countrydata) {
        return countrydata.population < 200000
    })
    console.log(pop_1)
    array = []
    //3.Print the following details name, capital, flag using forEach.
    console.log("%c3.Print the following details name, capital, flag using forEach.",style)
    countrydata.forEach(element => {
        array.push("[" + element.name, element.capital, element.flag + "]")
        //console.log(array)
    });
    console.log(array)
    //4.Print the total population of countries using the reduce method.
    console.log("%c4.Print the total population of countries using the reduce method",style)
    let pop = countrydata.reduce((initial, element) => {
        return initial + element.population
    }, 0)
    console.log(pop)
    //5.Print the country which uses US Dollars as currency.
    console.log("%c5.Print the country which uses US Dollars as currency.",style)
    let currency = countrydata.forEach((element, index) => {
        let one = element
        let find = JSON.stringify(one)
        if (find.includes("USD")) {
            console.log(element.name)
        }
    })
}
//6.To get count press button on page

let count = 0;
function count_click() {
    if(count==0)
    {
        console.log("%c6.To get count press button on page",style)
    }
    count = count + 1;
    console.log(count)
    //count++;
}